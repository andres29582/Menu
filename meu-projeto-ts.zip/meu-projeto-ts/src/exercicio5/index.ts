export function exibirPares() {
  console.log('Números pares de 1 a 20:');
  for (let i = 2; i <= 20; i += 2) {
    console.log(i);
  }
}
